#include "delay.h"
#include "sys.h"
#include "oled.h"
#include "gui.h"
#include "test.h"
#include "AHT20-21_DEMO_V1_3.h" 


//???????
uint32_t CT_data[2]={0,0};
//?????
volatile int  c1,t1;

//??LED????????
u8 temp[10];  
u8 hum[10];

//???PC13????
void GPIOC13_Init(void){
	GPIO_InitTypeDef  GPIO_InitStructure;
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOC, ENABLE);	
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_13;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_2MHz;
	GPIO_Init(GPIOC, &GPIO_InitStructure);	
	GPIO_ResetBits(GPIOC,GPIO_Pin_13);

}
//?????????
void Init(void);

//?????
void getData(void);

//?????
void showData(void);

int main(void)
{	
	//???
	Init();
	while(1){

		//????
		getData();
		//????
		showData();

		//????
		OLED_WR_Byte(0x2F,OLED_CMD);
		
		//??
		Delay_1ms(3100);
		//OLED_Clear(0); 
	}
	
}

//?????????
void Init(void){
	//???PC12
	GPIOC13_Init();		
	
	//???????	  
	delay_init();	   
	
	//???OLED 
	OLED_Init();

	//??(??)	
	OLED_Clear(0);    

	//??????	

	GUI_ShowCHinese(10,0,16,"������",1);
	
	GUI_ShowString(10,24,"632007060204",16,1);
	
	
	Delay_1ms(1000);
	
	AHT20_Init();
	/***********************************************************************************/
	/**///????,????????????,??100~500ms,??500ms
	/***********************************************************************************/
	
	Delay_1ms(1000);
	
	OLED_Clear(0); 
	OLED_WR_Byte(0x2E,OLED_CMD); //????

	OLED_WR_Byte(0x27,OLED_CMD); //????????? 26/27

	OLED_WR_Byte(0x00,OLED_CMD); //????

	OLED_WR_Byte(0x00,OLED_CMD); //??? 0

	OLED_WR_Byte(0x07,OLED_CMD); //??????

	OLED_WR_Byte(0x02,OLED_CMD); //??? 2

	OLED_WR_Byte(0x00,OLED_CMD); //????

	OLED_WR_Byte(0xFF,OLED_CMD); //????
	
	
	GUI_ShowCHinese(10,0,16,"ף���繫���ϰ�",1);	
}

//?????
void getData(){
	//AHT20_Read_CTdata(CT_data);       //???CRC??,????AHT20????????    ??????1S???
		AHT20_Read_CTdata_crc(CT_data);;  //crc???,??AHT20???????? 
		c1 = CT_data[0]*1000/1024/1024;  //???????c1(???10?)
		t1 = CT_data[1]*2000/1024/1024-500;//???????t1(???10?)

		//?????????
		temp[0]=t1/100+'0';
		temp[1]=(t1/10)%10+'0';
		temp[2]='.';
		temp[3]=t1%10+'0';
		temp[4]='\0';
		
		hum[0]=c1/100+'0';
		hum[1]=(c1/10)%10+'0';
		hum[2]='.';
		hum[3]=c1%10+'0';
		hum[4]=32;
		hum[5]='%';
		hum[6]='\0';
}


//?????
void showData(){
		//????
		GUI_ShowCHinese(15,28,16,"�¶�",1);
		GUI_ShowString(47,28,":",16,1);
		GUI_ShowString(62,28,temp,16,1);
		
		

		//????
		GUI_ShowCHinese(15,48,16,"ʪ��",1);
		GUI_ShowString(47,48,":",16,1);
		GUI_ShowString(62,48,hum,16,1);
}


